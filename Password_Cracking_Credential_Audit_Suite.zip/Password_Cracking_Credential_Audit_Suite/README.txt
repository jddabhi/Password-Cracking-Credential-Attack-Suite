PASSWORD CRACKING & CREDENTIAL ATTACK SUITE
Safe educational version | Python 3 | No third-party packages required

HOW TO RUN
1. Install Python 3.
2. Extract this ZIP.
3. Open a terminal in the extracted folder.
4. Run: python src/main.py
5. Select a module from the menu.

MODULES
1. Dictionary Generator: creates a small local wordlist from words supplied by the operator.
2. Synthetic Hash Demo: creates SHA-256 examples from fictional lab passwords. It does not extract OS hashes.
3. Brute-Force Simulator: tries a small bounded character space against a throwaway password typed locally.
4. Password Strength Analyzer: checks length, character groups, predictable patterns, and estimates entropy.
5. Audit Report: creates audit_report.txt and audit_report.json using built-in fictional sample data.

SAFETY / SCOPE
This submission is intentionally simulation-only. It does not access /etc/shadow, Windows SAM,
registry hives, online services, real user accounts, or third-party systems. The hash demo uses
synthetic examples. Real credential-store extraction is not implemented. Only use test data
you own or have explicit permission to assess.

LIMITATIONS
Entropy is an estimate, not a guarantee of crack time. Real attack cost depends on password
hashing algorithm, salt, work factor, hardware, and attacker resources. The brute-force module
is deliberately capped at length 4 and 200,000 attempts to keep the demonstration safe.

FILES
src/main.py                  Main menu
src/dictionary_generator.py  Wordlist generation and mutation
src/hash_demo.py             Synthetic hash demonstration
src/brute_force_simulator.py Bounded local simulation
src/password_strength.py     Defensive strength analysis
src/audit_report.py          Audit report generation
documentation/               Project report and presentation are supplied separately
