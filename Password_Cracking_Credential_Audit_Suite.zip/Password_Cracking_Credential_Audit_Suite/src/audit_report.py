"""Create a simple defensive audit report from local sample passwords."""
import json
from datetime import datetime
from password_strength import analyze

def build_report(samples):
    results = []
    for username, password in samples:
        item = analyze(password)
        results.append({"username": username, **item})
    weak = [x for x in results if x["rating"] == "WEAK"]
    moderate = [x for x in results if x["rating"] == "MODERATE"]
    strong = [x for x in results if x["rating"] == "STRONG"]
    report = {
        "title": "Password Security Audit Report",
        "generated": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "scope": "User-provided sample passwords only; no real accounts tested.",
        "summary": {"total": len(results), "weak": len(weak),
                    "moderate": len(moderate), "strong": len(strong)},
        "results": results,
        "recommendations": [
            "Require long, unique passwords or passphrases (prefer 14+ characters).",
            "Block commonly used and breached passwords.",
            "Enable multi-factor authentication.",
            "Store passwords with a unique salt and a password-hashing function such as Argon2id, scrypt, or bcrypt.",
            "Apply rate limits, progressive delays, and monitoring to login attempts.",
            "Never store plaintext passwords or share credential files."
        ]
    }
    with open("audit_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    with open("audit_report.txt", "w", encoding="utf-8") as f:
        f.write(report["title"] + "\\n")
        f.write("Generated: " + report["generated"] + "\\n")
        f.write("Scope: " + report["scope"] + "\\n\\n")
        f.write("Summary: " + json.dumps(report["summary"]) + "\\n\\n")
        for r in results:
            f.write(f"{r['username']}: {r['rating']} | entropy={r['estimated_entropy_bits']} bits\\n")
            for issue in r["issues"]: f.write("  - " + issue + "\\n")
        f.write("\\nRecommendations:\\n")
        for rec in report["recommendations"]: f.write("- " + rec + "\\n")
    return report

if __name__ == "__main__":
    samples = [("sample_user_1", "password123"), ("sample_user_2", "BlueTiger!2026"),
               ("sample_user_3", "r7#Qm2!vLp9@zX")]
    report = build_report(samples)
    print(json.dumps(report["summary"], indent=2))
    print("Created audit_report.txt and audit_report.json")
