"""Bounded brute-force demonstration against a password typed by the operator.

This is an educational simulation only: no network, account, hash file, or external
system is contacted. The search space and attempt limit are deliberately small.
"""
import itertools
import string
import time

def simulate(target, alphabet=string.ascii_lowercase + string.digits, max_length=4, max_attempts=200000):
    started = time.time()
    attempts = 0
    for length in range(1, max_length + 1):
        for chars in itertools.product(alphabet, repeat=length):
            guess = "".join(chars)
            attempts += 1
            if guess == target:
                elapsed = max(time.time() - started, 0.000001)
                return {"found": True, "attempts": attempts, "seconds": round(elapsed, 4),
                        "guess": guess, "rate_per_second": round(attempts / elapsed, 1)}
            if attempts >= max_attempts:
                elapsed = max(time.time() - started, 0.000001)
                return {"found": False, "attempts": attempts, "seconds": round(elapsed, 4),
                        "guess": None, "rate_per_second": round(attempts / elapsed, 1),
                        "note": "Attempt limit reached; target not found."}
    elapsed = max(time.time() - started, 0.000001)
    return {"found": False, "attempts": attempts, "seconds": round(elapsed, 4),
            "guess": None, "rate_per_second": round(attempts / elapsed, 1),
            "note": "Target was outside the configured search space."}

def main():
    print("LOCAL BRUTE-FORCE SIMULATOR (max 4 chars; lowercase + digits)")
    target = input("Enter a test password (use a throwaway sample): ")
    result = simulate(target)
    print("\\nSIMULATION RESULT")
    for k, v in result.items(): print(f"{k}: {v}")
    print("This result applies only to this tiny local search space.")

if __name__ == "__main__":
    main()
