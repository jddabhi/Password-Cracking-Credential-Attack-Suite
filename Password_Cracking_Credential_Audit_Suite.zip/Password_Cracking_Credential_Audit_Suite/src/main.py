"""Main menu for the Password Security Audit Suite."""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OPTIONS = {
    "1": ("Dictionary Generator", "dictionary_generator.py"),
    "2": ("Synthetic Hash Demo", "hash_demo.py"),
    "3": ("Brute-Force Simulator", "brute_force_simulator.py"),
    "4": ("Password Strength Analyzer", "password_strength.py"),
    "5": ("Generate Sample Audit Report", "audit_report.py"),
}

def main():
    while True:
        print("\\n=== PASSWORD SECURITY AUDIT SUITE ===")
        for key, (label, _) in OPTIONS.items(): print(f"{key}. {label}")
        print("0. Exit")
        choice = input("Choose module: ").strip()
        if choice == "0":
            print("Exiting safely.")
            break
        if choice in OPTIONS:
            subprocess.run([sys.executable, str(HERE / OPTIONS[choice][1])], cwd=Path.cwd())
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
