"""Create and inspect synthetic hash examples; does not read OS credential stores."""
import hashlib
import json

def create_demo_hashes():
    samples = {"demo_user_1": "LabOnly-Blue7!", "demo_user_2": "LabOnly-Green9!"}
    output = []
    for username, password in samples.items():
        output.append({"username": username, "algorithm": "SHA-256 (demo only)",
                       "hash": hashlib.sha256(password.encode()).hexdigest()})
    with open("sample_hashes.json", "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    return output

def main():
    print("SYNTHETIC HASH DEMONSTRATION")
    print("No /etc/shadow, Windows SAM, registry hive, or real account is accessed.")
    for item in create_demo_hashes():
        print(f"{item['username']} | {item['algorithm']} | {item['hash']}")
    print("Saved sample_hashes.json")

if __name__ == "__main__":
    main()
