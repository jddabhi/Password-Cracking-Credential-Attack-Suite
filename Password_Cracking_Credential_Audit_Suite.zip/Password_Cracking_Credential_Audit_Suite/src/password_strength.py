"""Password strength and entropy estimator for defensive education."""
import math
import re

COMMON = {"password", "password123", "123456", "qwerty", "admin", "welcome"}

def analyze(password):
    pool = 0
    pool += 26 if re.search(r"[a-z]", password) else 0
    pool += 26 if re.search(r"[A-Z]", password) else 0
    pool += 10 if re.search(r"\d", password) else 0
    pool += 32 if re.search(r"[^A-Za-z0-9]", password) else 0
    entropy = round(len(password) * math.log2(pool), 1) if pool else 0.0
    issues = []
    if len(password) < 12: issues.append("Use at least 12 characters.")
    if not re.search(r"[a-z]", password): issues.append("Add lowercase letters.")
    if not re.search(r"[A-Z]", password): issues.append("Add uppercase letters.")
    if not re.search(r"\d", password): issues.append("Add numbers.")
    if not re.search(r"[^A-Za-z0-9]", password): issues.append("Add symbols.")
    if password.lower() in COMMON: issues.append("This is a commonly used password.")
    if re.search(r"(.)\1{2,}", password): issues.append("Avoid repeated characters.")
    if re.search(r"1234|abcd|qwerty", password.lower()): issues.append("Avoid predictable sequences.")
    if password.lower() in COMMON or len(password) < 8:
        rating = "WEAK"
    elif entropy < 50 or issues:
        rating = "MODERATE"
    else:
        rating = "STRONG"
    return {"length": len(password), "estimated_entropy_bits": entropy,
            "rating": rating, "issues": issues or ["No basic policy issues detected."]}

def main():
    pw = input("Enter a sample password for local analysis: ")
    result = analyze(pw)
    print("\\nPASSWORD AUDIT")
    for k, v in result.items(): print(f"{k}: {v}")

if __name__ == "__main__":
    main()
