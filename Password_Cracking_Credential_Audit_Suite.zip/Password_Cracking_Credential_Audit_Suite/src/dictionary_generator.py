"""Safe wordlist generator for password-policy testing in an isolated lab."""
import itertools
import re

COMMON = ["password", "welcome", "admin", "qwerty", "letmein", "india"]

def mutations(word):
    """Return small, predictable variants; this does not access external accounts."""
    word = word.strip()
    if not word:
        return set()
    out = {word, word.lower(), word.upper(), word.capitalize()}
    leet = word.lower().translate(str.maketrans({"a":"@", "e":"3", "i":"1", "o":"0", "s":"$"}))
    out.add(leet)
    for suffix in ("1", "12", "123", "2024", "2025", "2026", "!"):
        out.add(word + suffix)
    return {x for x in out if x}

def generate(words, include_common=True, max_items=5000):
    candidates = set(COMMON if include_common else [])
    for word in words:
        candidates.update(mutations(word))
        if len(candidates) >= max_items:
            break
    return sorted(candidates)[:max_items]

def main():
    print("SAFE LAB WORDLIST GENERATOR")
    raw = input("Enter words separated by commas (e.g. project, blue, tiger): ")
    words = [x.strip() for x in raw.split(",") if x.strip()]
    year = input("Optional year (Enter to skip): ").strip()
    if year.isdigit() and len(year) == 4:
        words += [w + year for w in words]
    result = generate(words)
    with open("wordlist.txt", "w", encoding="utf-8") as f:
        f.write("\\n".join(result))
    print(f"Generated {len(result)} candidates in wordlist.txt")

if __name__ == "__main__":
    main()
